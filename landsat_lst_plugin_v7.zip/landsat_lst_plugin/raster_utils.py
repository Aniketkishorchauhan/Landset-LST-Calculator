# -*- coding: utf-8 -*-
"""Raster I/O helpers."""

import os
import numpy as np

try:
    from osgeo import gdal
    gdal.UseExceptions()
    GDAL_OK = True
except ImportError:
    GDAL_OK = False

from qgis.core import QgsRasterLayer


def read_band_as_array(layer: QgsRasterLayer, band: int = 1) -> np.ndarray:
    """Read one band into a float64 array. NaN replaces nodata."""
    if not GDAL_OK:
        raise RuntimeError("GDAL not available. Please ensure QGIS is properly installed.")
    ds = gdal.Open(layer.source())
    if ds is None:
        raise IOError(f"Cannot open: {layer.source()}")
    b   = ds.GetRasterBand(band)
    arr = b.ReadAsArray().astype(np.float64)   # float64 – keep full precision
    nd  = b.GetNoDataValue()
    if nd is not None:
        arr[arr == nd] = np.nan
    ds = None
    return arr


def write_output_raster(
    array: np.ndarray,
    reference_layer: QgsRasterLayer,
    output_path: str,
    nodata: float = -9999.0,
) -> QgsRasterLayer:
    """Write 2-D float32 GeoTIFF matching the CRS/extent of reference_layer."""
    if not GDAL_OK:
        raise RuntimeError("GDAL not available.")
    ref = gdal.Open(reference_layer.source())
    gt  = ref.GetGeoTransform()
    prj = ref.GetProjection()
    ref = None

    rows, cols = array.shape
    out = array.astype(np.float32).copy()
    out[~np.isfinite(out)] = nodata

    drv = gdal.GetDriverByName("GTiff")
    ds  = drv.Create(output_path, cols, rows, 1, gdal.GDT_Float32,
                     ["COMPRESS=LZW", "TILED=YES", "BIGTIFF=IF_SAFER"])
    ds.SetGeoTransform(gt)
    ds.SetProjection(prj)
    b = ds.GetRasterBand(1)
    b.SetNoDataValue(nodata)
    b.WriteArray(out)
    b.FlushCache()
    ds = None

    lyr = QgsRasterLayer(output_path, os.path.basename(output_path))
    return lyr
