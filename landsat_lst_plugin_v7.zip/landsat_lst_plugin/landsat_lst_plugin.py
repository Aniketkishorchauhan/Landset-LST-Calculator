# -*- coding: utf-8 -*-
"""Landsat LST Calculator - Main Plugin Class"""

import os, base64
from qgis.PyQt.QtCore    import Qt, QByteArray
from qgis.PyQt.QtGui     import QIcon, QPixmap, QColor
from qgis.PyQt.QtWidgets import QAction

# ── Satellite icon embedded as base64 (32×32 toolbar + 64×64 plugin-manager) ─
# Generated with pure Python – no PIL dependency.
# Written to disk at plugin load time so QGIS can find it reliably.
_ICON32_B64 = "iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAABiUlEQVR42tWXPU7DQBCFUwYJRJQiQkQKDYoQBaJAEKE4sfMPBJwCUdBQQoFyFy5ETc0NuAE3GPz5B7AJa4d45WWlJ61nx/PezO7au6XSf2u1mwdRoRBSrWKSQcvtmRK5iViWOFchqxCrhKxEvtZ2Zb19JRsh6GPLXUSSHKKqdSk1ayrbnQuph6CPjTF8sopYgtyVihd8qzOVnc657HbPpNmdyJ4dgD42xvDBt5xSEaWIeOldPzMyhWTfHsuhPZIjZyjHzsAHfWyM4YNvNUWEciq+Z18JycnywCOB0Or1pdd3ZBCCPjbG8MGXd4JK/KEK0QDzSUnJisAtjwCySd+W2etbJqjWxEIBGBrPT5/YnN/GnsH10PKDpzV8mIq0eDERWQTcjU7jAuaNXwWwO3IXcD9ufQmA/P1loQh82KK5C3icnAQCIvIICRH41LUKyFABLQJiU5CyBrRMwY9FqNgFWhah1m1Y+IfIqE9xYT+jwn/HRhxIjDiSFX4oNeJYbsTFxJirmRGXU53tA5I/wcoUepZHAAAAAElFTkSuQmCC"
_ICON64_B64 = "iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAEAklEQVR42u1b624SQRTuzwptECjFCgW0sdVqrdVUaMv9blsKidHEJkbjJakxIb6KL+Rvf/sGvoFvMJ4Pz1RAdmXZ2WUps8mXwM5l9/vOOTOzZ2cXFvThzrH68kJYwdwRvjKCmJFYzHbGwkwKYYfwJIJ4lrgq0uOKMTfEPSXENImbCTF35F0XwYvkXRPBy+QdF8HrxI2EmLLl2+IawTcEnFvsYQY8wSp5kPMTlrNnIkC4nmuJ4BBwDmWo478UxIMiWCHvY9IgFyKs5E7FKiFKuJEfRJTLUCfEgqCtzwEhbIkwDnlJPNhHei1/ImKEOCGRPxbJIeBcnOugrhQj6JAQEwkwDnm4L1w5TDcOq94kMutM8nbhmdgg3Ck0e9hkyP8oQx3URRu0RR9hDg//tEUwF6AtltjqEbY4SKQIIAaiW4R7xYa4z3jAkP9RtsWioE2KhUBfEfYGXEPVYGlJgP+Rh5siduG6cONkH3FJ+mGxLh4R9ko18ZjwhIHfOIcy1JFiSCHQV4zDIsQh4boIZgIsMXm4K+IYloNL3y02e2R2iRRI7peqIk3IEA7KVXFYrvSA3xkuQx3U3WUh0Af6SvEYEWUR/niCSwKYkUdcBtnyuMFbHOOw4A5be59JHxHZHKFQLosiocTAb5xDGepkWAi0RR/oC32i7zh7Aq7pd8sLjATw8YAXYbeXlt9md4d7p5k4CJYrJVEl1CpFUSc0GPiNcyhDHdRFG7RFH+hrm0VIcTjgmgFFs4OpAGbz/jKP9msc89LykjwsCavCyjUiBrKdHz+VIXw5Hji4LjCzfpDjfp0HPMTrzhB5WBQWPq4WRIuAG1dxoJ8oh4KjXiALEt++GiLQPTctPyHi7WpePK/llAqAdQIWS/ACO/fnuAAdIv+CyL+qZY0F6CYsCwDPw4CIZbMjAvTHhp0LgPx5PSve1A8HBQBpI4whQJIXSSGFAgyI0B//di4Ay4P8h8bBXwHMyI8hAvrBsjnGYWBXgJFeoEqA1/Uj8Z7IXzQyxgL8+m5ZgI2+dYGnBXhL1v9IAnxupkcLAPISFgTAtIunyKjXBXhHAsD6XSmAEXkLIkgBMA4gn+BpAeD+n0iAL82nSj1g88oIMOEYMDMC/BMCimaBmQmBkYOggnXAzAyCI6dBBSvBmZkGRy6EFDwLuLYQcmwpbFMAx5fCrj4MTSCA4w9DZvkAPIKucNobWRpMScjh7XEWqD8X4MbjsOP5AJUJEVVwNSGiKiUGIU5ZjDPyCqDF51DW6OUHS702OU6QyrygTI7K2HclJTb3SVGdFtcvRvSrMf1yVL8e1xsk9BYZvUlKb5PTGyX1Vlm9WVpvl9cfTOhPZvRHU/qzOf3hpP50Vn88PQ/Hb5/xYniOdzt+AAAAAElFTkSuQmCC"


def _write_icon_to_disk(plugin_dir: str):
    """
    Write icon.png to the plugin directory.
    Called once at module import so the file is always present before initGui().
    Uses the 64×64 version for the plugin manager preview.
    """
    dst = os.path.join(plugin_dir, "icon.png")
    try:
        data = base64.b64decode(_ICON64_B64)
        with open(dst, "wb") as f:
            f.write(data)
    except Exception:
        pass   # keep existing file if write fails


def _make_qicon(plugin_dir: str) -> QIcon:
    """
    Build QIcon with three fallback levels:
      1. Load icon.png from disk (absolute path – most reliable on all platforms)
      2. Load from 32×32 base64 via QByteArray (avoids loadFromData format issues)
      3. Solid teal 32×32 QPixmap (always visible)
    """
    # Level 1 – disk file (written by _write_icon_to_disk above)
    disk = os.path.join(plugin_dir, "icon.png")
    if os.path.isfile(disk):
        icon = QIcon(disk)
        # QIcon(path) is never null even if load fails – check with pixmap()
        test_pm = icon.pixmap(32, 32)
        if not test_pm.isNull():
            return icon

    # Level 2 – base64 via QByteArray
    try:
        ba = QByteArray(base64.b64decode(_ICON32_B64))
        pm = QPixmap()
        pm.loadFromData(ba)
        if not pm.isNull():
            return QIcon(pm)
    except Exception:
        pass

    # Level 3 – solid teal fallback (always visible in toolbar)
    pm = QPixmap(32, 32)
    pm.fill(QColor(13, 115, 119))
    return QIcon(pm)


class LandsatLSTPlugin:

    def __init__(self, iface):
        self.iface      = iface
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.actions    = []
        self.menu       = "Landsat LST"
        self.toolbar    = self.iface.addToolBar("LandsatLST")
        self.toolbar.setObjectName("LandsatLST")
        self.dlg        = None
        # Write icon to disk immediately so it is available for initGui()
        _write_icon_to_disk(self.plugin_dir)

    def initGui(self):
        icon   = _make_qicon(self.plugin_dir)
        action = QAction(icon, "Landsat LST Calculator", self.iface.mainWindow())
        action.setToolTip(
            "Landsat LST Calculator\n"
            "Compute Land Surface Temperature from Landsat 5 / 7 / 8 / 9 imagery"
        )
        action.triggered.connect(self.run)
        self.toolbar.addAction(action)
        self.iface.addPluginToRasterMenu(self.menu, action)
        self.actions.append(action)

    def unload(self):
        for action in self.actions:
            self.iface.removePluginRasterMenu(self.menu, action)
            self.iface.removeToolBarIcon(action)
        del self.toolbar

    def run(self):
        from .ui.lst_dialog import LSTDialog
        if self.dlg is None:
            self.dlg = LSTDialog(self.iface)
        self.dlg.show()
        self.dlg.raise_()
        self.dlg.activateWindow()
