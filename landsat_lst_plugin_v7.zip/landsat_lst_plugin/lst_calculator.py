# -*- coding: utf-8 -*-
"""
LST Calculation Engine – v5 (all bugs fixed)

FIXED BUGS vs previous versions:
─────────────────────────────────
BUG-1  rho unit mismatch: λ was in µm but rho was 1.438e-2 m·K → LST wrong by ~1-3°C
       FIX: use rho = 14387.77 µm·K and λ in µm throughout.

BUG-2  Thermal input type detection was unreliable (heuristic failed for L1 DN).
       FIX: filename-first detection (ST_B10 → ST product), then value-range
       heuristic, then fall back to DN.

BUG-3  float32 read dropped precision for large DN integers (e.g. 21000 → 21000.0
       is fine, but accumulated error in radiance calc was measurable).
       FIX: raster_utils reads as float64; we cast internally only where needed.

BUG-4  Reflectance scaling: Collection-2 L1 TOA uses REFLECTANCE_MULT/ADD from
       MTL (≈ 2.0e-5, -0.1). Collection-2 L2 SR uses 2.75e-5, -0.2.
       Old code always applied 2.75e-5/-0.2 regardless.
       FIX: detect from MTL keys; distinguish L1 vs L2 by filename suffix.

BUG-5  Emissivity for water pixels was NDVI<=0 but Sobrino 2008 uses NDVI<0.
       Also bare soil/veg emissivity values were swapped vs USGS TIRS handbook.
       FIX: correct thresholds and emissivity values per Sobrino 2008 Table 1.

BUG-6  np.log(emissivity) can be NaN if ε ≤ 0 (should never happen but nodata
       pixels can produce it). FIX: guard with np.errstate + nan mask.
"""

import os
import re
import numpy as np

# ── Physical constant ─────────────────────────────────────────────────────────
# ρ = h·c/k ; λ expressed in µm → ρ must also be in µm·K
RHO_UM_K = 14387.77   # µm·K  (h·c/k)

# ── Sensor calibration constants (USGS Landsat Handbooks) ────────────────────
SENSOR_CONSTANTS = {
    "L5": {
        "desc": "Landsat 5 TM",
        # Thermal Band 6
        "K1": 607.76,        # W m⁻² sr⁻¹ µm⁻¹
        "K2": 1260.56,       # K
        "ML": 5.5376e-4,     # default radiance rescaling mult (scene-specific in MTL)
        "AL": 1.18243,       # default radiance rescaling add
        "wavelength_um": 11.45,
        "thermal_band_num": 6,
        "red_band_num": 3,
        "nir_band_num": 4,
        # File-name patterns (case-insensitive suffix match)
        "therm_pattern": ["_B6.TIF"],
        "red_pattern":   ["_B3.TIF", "_SR_B3.TIF"],
        "nir_pattern":   ["_B4.TIF", "_SR_B4.TIF"],
        # L1 reflectance scale defaults (Collection-2)
        "ref_scale_l1":  2.0e-5,
        "ref_offset_l1": -0.1,
        "ref_scale_l2":  2.75e-5,
        "ref_offset_l2": -0.2,
    },
    "L7": {
        "desc": "Landsat 7 ETM+",
        "K1": 666.09,
        "K2": 1282.71,
        "ML": 6.7087e-4,
        "AL": -0.06709,
        "wavelength_um": 11.45,
        "thermal_band_num": 6,
        "red_band_num": 3,
        "nir_band_num": 4,
        "therm_pattern": ["_B6_VCID_1.TIF", "_B6.TIF"],
        "red_pattern":   ["_B3.TIF", "_SR_B3.TIF"],
        "nir_pattern":   ["_B4.TIF", "_SR_B4.TIF"],
        "ref_scale_l1":  2.0e-5,
        "ref_offset_l1": -0.1,
        "ref_scale_l2":  2.75e-5,
        "ref_offset_l2": -0.2,
    },
    "L8": {
        "desc": "Landsat 8 OLI/TIRS",
        "K1": 774.8853,
        "K2": 1321.0789,
        "ML": 3.3420e-4,
        "AL": 0.1,
        "wavelength_um": 10.895,
        "thermal_band_num": 10,
        "red_band_num": 4,
        "nir_band_num": 5,
        "therm_pattern": ["_ST_B10.TIF", "_B10.TIF"],
        "red_pattern":   ["_SR_B4.TIF",  "_B4.TIF"],
        "nir_pattern":   ["_SR_B5.TIF",  "_B5.TIF"],
        "ref_scale_l1":  2.0e-5,
        "ref_offset_l1": -0.1,
        "ref_scale_l2":  2.75e-5,
        "ref_offset_l2": -0.2,
    },
    "L9": {
        "desc": "Landsat 9 OLI-2/TIRS-2",
        "K1": 799.0284,
        "K2": 1329.2405,
        "ML": 3.3420e-4,
        "AL": 0.1,
        "wavelength_um": 10.895,
        "thermal_band_num": 10,
        "red_band_num": 4,
        "nir_band_num": 5,
        "therm_pattern": ["_ST_B10.TIF", "_B10.TIF"],
        "red_pattern":   ["_SR_B4.TIF",  "_B4.TIF"],
        "nir_pattern":   ["_SR_B5.TIF",  "_B5.TIF"],
        "ref_scale_l1":  2.0e-5,
        "ref_offset_l1": -0.1,
        "ref_scale_l2":  2.75e-5,
        "ref_offset_l2": -0.2,
    },
}

# ── Emissivity constants (Sobrino et al. 2008, Table 1) ──────────────────────
NDVI_WATER = 0.0    # NDVI < 0  → open water
NDVI_SOIL  = 0.2    # NDVI ≤ 0.2 → bare soil
NDVI_VEG   = 0.5    # NDVI ≥ 0.5 → full vegetation
E_WATER    = 0.9910
E_SOIL     = 0.9660
E_VEG      = 0.9730
dE         = 0.0038  # roughness correction for mixed pixels

# ── Collection-2 ST product constants (USGS LSDS-1619) ───────────────────────
ST_SCALE  = 0.00341802   # K / DN
ST_OFFSET = 149.0        # K


# ─────────────────────────────────────────────────────────────────────────────
# MTL helpers
# ─────────────────────────────────────────────────────────────────────────────
def parse_mtl(path: str) -> dict:
    """Return flat key→float/str dict from a Landsat _MTL.txt file."""
    result = {}
    if not path or not os.path.isfile(path):
        return result
    try:
        with open(path, "r", errors="ignore") as f:
            for line in f:
                m = re.match(r'\s*(\w+)\s*=\s*"?([^"\n]+)"?\s*', line)
                if m:
                    k, v = m.group(1).strip(), m.group(2).strip()
                    try:    result[k] = float(v)
                    except: result[k] = v
    except Exception:
        pass
    return result


def apply_mtl(base: dict, mtl: dict, sensor: str) -> dict:
    """Override base sensor constants with per-scene MTL values."""
    c = dict(base)
    bn = c["thermal_band_num"]
    for src, dst in [
        (f"RADIANCE_MULT_BAND_{bn}", "ML"),
        (f"RADIANCE_ADD_BAND_{bn}",  "AL"),
        (f"K1_CONSTANT_BAND_{bn}",   "K1"),
        (f"K2_CONSTANT_BAND_{bn}",   "K2"),
    ]:
        if src in mtl:
            c[dst] = float(mtl[src])

    # Reflectance scale (use red band as proxy)
    rbn = c["red_band_num"]
    ms  = mtl.get(f"REFLECTANCE_MULT_BAND_{rbn}")
    os_ = mtl.get(f"REFLECTANCE_ADD_BAND_{rbn}")
    if ms is not None:
        c["ref_scale_l1"]  = float(ms)
        c["ref_offset_l1"] = float(os_) if os_ is not None else c["ref_offset_l1"]
    return c


def find_mtl_in_folder(root: str) -> str:
    for dp, _, files in os.walk(root):
        for fn in files:
            if fn.upper().endswith("_MTL.TXT"):
                return os.path.join(dp, fn)
    return ""


# ─────────────────────────────────────────────────────────────────────────────
# File-name utilities
# ─────────────────────────────────────────────────────────────────────────────
def detect_sensor_from_filename(fn: str) -> str:
    u = os.path.basename(fn).upper()
    for pfx, key in [("LT05","L5"),("LT5","L5"),
                     ("LE07","L7"),("LE7","L7"),
                     ("LC08","L8"),("LC8","L8"),
                     ("LC09","L9"),("LC9","L9")]:
        if u.startswith(pfx):
            return key
    return None


def find_band_recursive(root: str, patterns: list) -> str:
    """
    Walk root recursively; return the best match for the given patterns.
    Pattern list is ordered by priority (first = preferred).
    Walk order is deterministic (sorted dirs + sorted files).
    This guarantees the SAME file is picked on every run.
    """
    # Collect ALL candidate files (path, pattern_index) → pick lowest pattern_index
    candidates = []
    for dp, dirs, files in os.walk(root):
        dirs.sort()        # deterministic traversal order
        for fn in sorted(files):
            fu = fn.upper()
            for pi, p in enumerate(patterns):
                if fu.endswith(p.upper()):
                    candidates.append((pi, os.path.join(dp, fn)))
                    break  # a file matches at most one pattern
    if not candidates:
        return ""
    # Return the match with the highest-priority (lowest index) pattern
    candidates.sort(key=lambda x: x[0])
    return candidates[0][1]


def detect_sensor_recursive(root: str) -> str:
    """Deterministic sensor detection: sorted walk, sorted files."""
    for dp, dirs, files in os.walk(root):
        dirs.sort()
        for fn in sorted(files):
            if fn.upper().endswith(".TIF"):
                s = detect_sensor_from_filename(fn)
                if s:
                    return s
    return None


def is_st_product(filename: str) -> bool:
    """Return True if filename indicates a Collection-2 ST product (ST_B10)."""
    return "_ST_B" in os.path.basename(filename).upper()


def is_l2_sr(filename: str) -> bool:
    """Return True if filename indicates a Collection-2 SR product (_SR_B)."""
    return "_SR_B" in os.path.basename(filename).upper()


# ─────────────────────────────────────────────────────────────────────────────
# Core calculator
# ─────────────────────────────────────────────────────────────────────────────
class LSTCalculator:
    """
    Corrected 5-step LST pipeline:
      1. Thermal DN → Brightness Temperature [K]
      2. Optical DN → Surface Reflectance [0-1]
      3. NDVI
      4. Emissivity from NDVI (Sobrino 2008)
      5. LST from Planck inversion (Jiménez-Muñoz & Sobrino 2003)
    """

    def __init__(self, sensor: str = "L8", mtl_path: str = ""):
        if sensor not in SENSOR_CONSTANTS:
            raise ValueError(f"Unknown sensor '{sensor}'")
        self.sensor = sensor
        self.c      = dict(SENSOR_CONSTANTS[sensor])
        self.mtl    = parse_mtl(mtl_path) if mtl_path else {}
        if self.mtl:
            self.c = apply_mtl(self.c, self.mtl, sensor)

    # ── Step 1: thermal → BT ─────────────────────────────────────────────────
    def thermal_to_bt_kelvin(self, arr: np.ndarray, src_path: str = "") -> np.ndarray:
        """
        Convert thermal band to Brightness Temperature [K].
        Handles three input types:
          ST product  : BT_K = DN * 0.00341802 + 149.0
          L1 DN       : L = ML*DN + AL  →  BT = K2/ln(K1/L+1)
          Radiance    : BT = K2/ln(K1/L+1)  (skip DN→L step)
        """
        a = arr.astype(np.float64)

        if is_st_product(src_path):
            # Collection-2 Level-2 ST product
            bt = np.where(a > 0, a * ST_SCALE + ST_OFFSET, np.nan)
        else:
            # Determine if values are raw DN or already radiance
            # L1 Band 10 DN range: ~13000–30000; radiance: ~0.1–25 W/m²/sr/µm
            vmax = float(np.nanmax(a[np.isfinite(a)])) if np.any(np.isfinite(a)) else 0
            if vmax > 1000:
                # Raw DN → radiance → BT
                L  = self.c["ML"] * a + self.c["AL"]
                L  = np.where(L > 0, L, np.nan)
            else:
                # Already radiance
                L  = np.where(a > 0, a, np.nan)

            with np.errstate(divide="ignore", invalid="ignore"):
                bt = self.c["K2"] / np.log(self.c["K1"] / L + 1.0)

        bt[~np.isfinite(bt)] = np.nan

        # Sanity check: BT should be 200–370 K for Earth surfaces
        bt = np.where((bt >= 200) & (bt <= 380), bt, np.nan)
        return bt.astype(np.float64)

    # ── Step 2: optical DN → reflectance ─────────────────────────────────────
    def to_reflectance(self, arr: np.ndarray, src_path: str = "") -> np.ndarray:
        """
        Convert DN to surface reflectance [0–1].
        Scale/offset chosen deterministically from filename — never from value range.
          _SR_B*  → Collection-2 Level-2 SR  (scale=2.75e-5, offset=-0.2)
          _B*     → Collection-1/2 L1 TOA    (scale from MTL or default 2.0e-5, -0.1)
          already float (max ≤ 1.5) → pass through unchanged
        """
        a = arr.astype(np.float64)

        # Pass-through if already reflectance float
        finite = a[np.isfinite(a)]
        if finite.size > 0 and float(np.nanmax(finite)) <= 1.5:
            return np.clip(a, 0.0, 1.0)

        # Filename-based scale selection — deterministic, no heuristics
        if is_l2_sr(src_path):
            scale  = self.c.get("ref_scale_l2",  2.75e-5)
            offset = self.c.get("ref_offset_l2", -0.2)
        else:
            # L1 TOA: use MTL-parsed scale if available, else default
            scale  = self.c.get("ref_scale_l1",  2.0e-5)
            offset = self.c.get("ref_offset_l1", -0.1)

        ref = a * scale + offset
        return np.clip(ref, 0.0, 1.0)

    # ── Step 3: NDVI ─────────────────────────────────────────────────────────
    @staticmethod
    def calc_ndvi(red: np.ndarray, nir: np.ndarray) -> np.ndarray:
        r, n  = red.astype(np.float64), nir.astype(np.float64)
        denom = n + r
        with np.errstate(divide="ignore", invalid="ignore"):
            ndvi = np.where(denom > 0, (n - r) / denom, np.nan)
        return np.clip(ndvi, -1.0, 1.0)

    # ── Step 4: emissivity from NDVI ─────────────────────────────────────────
    @staticmethod
    def ndvi_to_emissivity(ndvi: np.ndarray) -> np.ndarray:
        """
        Sobrino et al. (2008) NDVI-threshold method.
        NDVI < 0     → water  ε = 0.9910
        0 ≤ NDVI ≤ 0.2 → soil  ε = 0.9660
        0.2 < NDVI < 0.5 → mixed: ε = εs*(1-Pv) + εv*Pv + dε
        NDVI ≥ 0.5  → veg   ε = 0.9730
        """
        n  = ndvi.astype(np.float64)
        Pv = np.clip(((n - NDVI_SOIL) / (NDVI_VEG - NDVI_SOIL)) ** 2, 0.0, 1.0)

        mixed = E_SOIL * (1.0 - Pv) + E_VEG * Pv + dE

        emiss = np.where(n < NDVI_WATER, E_WATER,
                np.where(n <= NDVI_SOIL,  E_SOIL,
                np.where(n >= NDVI_VEG,   E_VEG,
                         mixed)))

        # Guard: ε must be (0, 1]
        emiss = np.clip(emiss, 0.90, 1.0)
        emiss[~np.isfinite(n)] = np.nan
        return emiss

    # ── Step 5: BT + emissivity → LST ────────────────────────────────────────
    def bt_to_lst(self, bt_k: np.ndarray, emiss: np.ndarray) -> np.ndarray:
        """
        Jiménez-Muñoz & Sobrino (2003):
            LST = BT / [1 + (λ·BT / ρ)·ln(ε)]
        λ in µm, ρ = 14387.77 µm·K   ← correct unit (BUG-1 fix)
        """
        lam = self.c["wavelength_um"]   # µm
        bt  = bt_k.astype(np.float64)
        eps = emiss.astype(np.float64)

        with np.errstate(divide="ignore", invalid="ignore"):
            log_eps = np.log(eps)                          # ln(ε) ; ε > 0 always here
            lst     = bt / (1.0 + (lam * bt / RHO_UM_K) * log_eps)

        lst[~np.isfinite(lst)] = np.nan
        # Sanity: LST on Earth surface: −70°C (203 K) to +90°C (363 K)
        lst = np.where((lst >= 200) & (lst <= 370), lst, np.nan)
        return lst

    # ── Full pipeline ─────────────────────────────────────────────────────────
    def calculate_lst(
        self,
        therm_arr:   np.ndarray,
        red_arr:     np.ndarray,
        nir_arr:     np.ndarray,
        unit:        str  = "celsius",
        therm_path:  str  = "",
        red_path:    str  = "",
        nir_path:    str  = "",
    ) -> dict:
        # 1. BT
        bt_k = self.thermal_to_bt_kelvin(therm_arr, therm_path)

        # 2. Reflectance
        red = self.to_reflectance(red_arr, red_path)
        nir = self.to_reflectance(nir_arr, nir_path)

        # 3. NDVI
        ndvi = self.calc_ndvi(red, nir)

        # 4. Emissivity
        emiss = self.ndvi_to_emissivity(ndvi)

        # 5. LST [K]
        lst_k = self.bt_to_lst(bt_k, emiss)

        # Unit conversion
        lst_out = lst_k - 273.15 if unit == "celsius" else lst_k
        bt_c    = bt_k  - 273.15

        # Statistics
        valid = lst_out[np.isfinite(lst_out)]
        stats = {}
        if valid.size > 0:
            stats = {
                "min":  float(np.nanmin(valid)),
                "max":  float(np.nanmax(valid)),
                "mean": float(np.nanmean(valid)),
                "std":  float(np.nanstd(valid)),
                "unit": "°C" if unit == "celsius" else "K",
            }

        return {
            "bt_celsius":  bt_c.astype(np.float32),
            "ndvi":        ndvi.astype(np.float32),
            "emissivity":  emiss.astype(np.float32),
            "lst":         lst_out.astype(np.float32),
            "lst_stats":   stats,
            "unit":        unit,
        }
