# 🌡 Landsat LST Calculator – QGIS Plugin

A QGIS 3 plugin for calculating **Land Surface Temperature (LST)** from Landsat 8 and Landsat 9 imagery using the radiative transfer / mono-window algorithm.

---

## Algorithm Overview

The plugin implements the following processing chain:

```
Band 10 DN  ──→  TOA Radiance  ──→  Brightness Temperature (BT)
                                              │
Band 4 (Red) ─┐                              ▼
              ├──→  NDVI  ──→  Emissivity (ε)
Band 5 (NIR) ─┘                              │
                                              ▼
                                    LST (Planck inversion)
```

### Step-by-step

| Step | Formula | Notes |
|------|---------|-------|
| **1. TOA Radiance** | `L = ML × DN + AL` | ML/AL from MTL metadata |
| **2. Brightness Temp.** | `BT = K2 / ln(K1/L + 1)` | Planck function inversion |
| **3. NDVI** | `(NIR − Red) / (NIR + Red)` | Band 5 / Band 4 |
| **4. Emissivity** | Mixed-pixel method (Sobrino 2001) | NDVI soil < 0.2, veg > 0.5 |
| **5. LST** | `LST = BT / [1 + (λ·BT/ρ)·ln(ε)]` | λ = 10.895 µm |

### Sensor constants

| Constant | Landsat 8 | Landsat 9 |
|----------|-----------|-----------|
| K1 (W/m²·sr·µm) | 774.8853 | 799.0284 |
| K2 (K) | 1321.0789 | 1329.2405 |
| Radiance mult (ML) | 3.342 × 10⁻⁴ | 3.342 × 10⁻⁴ |
| Radiance add (AL) | 0.1 | 0.1 |

---

## Installation

### Method 1 – Install from ZIP (recommended)

1. Open QGIS → **Plugins → Manage and Install Plugins → Install from ZIP**
2. Browse to `landsat_lst_plugin.zip`
3. Click **Install Plugin**

### Method 2 – Manual install

Copy the `landsat_lst_plugin/` folder to your QGIS plugins directory:

| OS | Path |
|----|------|
| Windows | `C:\Users\<user>\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins\` |
| macOS | `~/Library/Application Support/QGIS/QGIS3/profiles/default/python/plugins/` |
| Linux | `~/.local/share/QGIS/QGIS3/profiles/default/python/plugins/` |

Then enable it via **Plugins → Manage and Install Plugins**.

---

## Usage

1. Load your Landsat scene bands into QGIS as separate raster layers (or as a multi-band raster).
2. Go to **Raster → Landsat LST → Calculate LST from Landsat** (or click the toolbar button).
3. Select the sensor (**Landsat 8** or **Landsat 9**).
4. Map the three required input layers:
   - **Band 10** – Thermal Infrared (TIRS)
   - **Band 4** – Red (OLI)
   - **Band 5** – Near Infrared (OLI)
5. Set the band number within each layer (usually **1** for single-band TIFFs).
6. Choose output unit (**Celsius** or **Kelvin**).
7. Optionally tick extra outputs: Brightness Temperature, NDVI, Emissivity.
8. Select an **output folder** and click **▶ Calculate LST**.

Output GeoTIFFs are written compressed (LZW) and, if the option is ticked, added directly to the QGIS project.

---

## Input data requirements

| Requirement | Detail |
|-------------|--------|
| Sensor | Landsat 8 or 9 (Collection 1 or 2) |
| Band 10 | Raw DN *or* TOA radiance (DN recommended) |
| Band 4/5 | Raw DN scaled integers (Collection 2: scale=0.0000275, offset=−0.2) |
| Projection | Any; output inherits Band 10's CRS |
| Extent | All bands should cover the same area (ideally identical extent) |

> **Tip:** Download scenes from [USGS EarthExplorer](https://earthexplorer.usgs.gov/) or [Google Earth Engine](https://developers.google.com/earth-engine/datasets/catalog/landsat).

---

## Output files

| File | Description | Unit |
|------|-------------|------|
| `LST_C.tif` / `LST_K.tif` | Land Surface Temperature | °C or K |
| `BrightnessTemp_C.tif` | At-sensor brightness temperature | °C |
| `NDVI.tif` | Normalized Difference Vegetation Index | −1 to 1 |
| `Emissivity.tif` | Estimated land-surface emissivity | 0.97 – 0.99 |

---

## References

- Jiménez-Muñoz, J.C. & Sobrino, J.A. (2003). *A generalized single-channel method for retrieving land surface temperature from remote sensing data.* JGR Atmospheres.
- Sobrino, J.A., et al. (2001). *Land surface temperature retrieval from LANDSAT TM 5.* Remote Sensing of Environment.
- USGS (2019). *Landsat 8 Collection 1 Level 1 Data Format Control Book.*

---

## Requirements

- QGIS ≥ 3.16
- Python ≥ 3.7
- GDAL / osgeo (bundled with QGIS)
- NumPy (bundled with QGIS)

---

## License

MIT License – see `LICENSE.txt`
