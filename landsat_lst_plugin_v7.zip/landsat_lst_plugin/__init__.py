# -*- coding: utf-8 -*-
"""
Landsat LST Calculator Plugin
"""


def classFactory(iface):
    from .landsat_lst_plugin import LandsatLSTPlugin
    return LandsatLSTPlugin(iface)
