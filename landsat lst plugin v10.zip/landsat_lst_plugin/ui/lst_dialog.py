# -*- coding: utf-8 -*-
"""
Landsat LST Calculator Dialog – v5
All bugs fixed:
  • stat label key "stddev" was wrong (dict had "std") → fixed
  • written.items() iterated non-layer values → filter QgsRasterLayer instances
  • find_recursive / detect_sensor_recursive were defined locally AND imported → one source of truth
  • worker now passes src_path for therm/red/nir so ST vs L1 detection works
  • layer source passed to calculator for correct scale selection
"""

import os, shutil, zipfile, traceback, tempfile
import numpy as np

from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QComboBox,
    QPushButton, QFileDialog, QProgressBar, QLineEdit,
    QGroupBox, QRadioButton, QCheckBox, QTextEdit, QSizePolicy,
    QMessageBox, QFrame, QButtonGroup, QWidget, QGridLayout,
    QSpinBox, QScrollArea,
)
from qgis.PyQt.QtCore import Qt, QThread, pyqtSignal, QRect
from qgis.PyQt.QtGui  import QFont, QColor, QPixmap, QPainter, QBrush, QPen, QLinearGradient
from qgis.core        import QgsProject, QgsRasterLayer

from ..qa_mask import (
    build_mask, apply_mask, mask_statistics,
    QA_PATTERNS, QA_PATTERNS_C1,
)
from ..lst_calculator import (
    LSTCalculator, SENSOR_CONSTANTS,
    detect_sensor_from_filename, detect_sensor_recursive,
    find_band_recursive, find_mtl_in_folder,
)
from ..raster_utils import read_band_as_array, write_output_raster


# ─────────────────────────────────────────────────────────────────────────────
# Background worker
# ─────────────────────────────────────────────────────────────────────────────
class LSTWorker(QThread):
    progress = pyqtSignal(int, str)
    finished = pyqtSignal(dict)
    error    = pyqtSignal(str)

    def __init__(self, params: dict):
        super().__init__()
        self.p = params

    def run(self):
        try:
            p    = self.p
            calc = LSTCalculator(sensor=p["sensor"], mtl_path=p.get("mtl_path", ""))

            self.progress.emit(10, "Reading thermal band…")
            b_th = read_band_as_array(p["layer_therm"], p["band_therm"])
            self.progress.emit(24, "Reading Red band…")
            b_r  = read_band_as_array(p["layer_red"],  p["band_red"])
            self.progress.emit(38, "Reading NIR band…")
            b_n  = read_band_as_array(p["layer_nir"],  p["band_nir"])

            # ── QA masking ─────────────────────────────────────────────
            qa_mask_arr = None
            if p.get("apply_mask") and p.get("qa_path"):
                self.progress.emit(46, "Reading QA_PIXEL band…")
                try:
                    from osgeo import gdal
                    ds  = gdal.Open(p["qa_path"])
                    qa_raw = ds.GetRasterBand(1).ReadAsArray().astype("uint16")
                    ds  = None
                    qa_mask_arr = build_mask(
                        qa_raw,
                        mask_cloud   = p.get("mask_cloud",   True),
                        mask_shadow  = p.get("mask_shadow",  True),
                        mask_water   = p.get("mask_water",   False),
                        mask_snow    = p.get("mask_snow",    False),
                        mask_cirrus  = p.get("mask_cirrus",  True),
                        mask_dilated = p.get("mask_dilated", True),
                    )
                    ms = mask_statistics(qa_mask_arr)
                    self.progress.emit(49, f"Mask built — {ms['masked']:,} px masked ({ms['pct_masked']}%)")
                except Exception as qe:
                    self.progress.emit(49, f"⚠ QA mask failed: {qe} — continuing without mask")

            self.progress.emit(52, "Computing LST…")
            results = calc.calculate_lst(
                b_th, b_r, b_n,
                unit       = p["unit"],
                therm_path = p["layer_therm"].source(),
                red_path   = p["layer_red"].source(),
                nir_path   = p["layer_nir"].source(),
            )

            # Apply mask to all outputs
            if qa_mask_arr is not None:
                for key in ("lst", "bt_celsius", "ndvi", "emissivity"):
                    if key in results and results[key] is not None:
                        results[key] = apply_mask(results[key], qa_mask_arr).astype("float32")
                # Recompute stats on masked LST
                valid = results["lst"][~np.isnan(results["lst"])]
                if valid.size > 0:
                    u = results["lst_stats"].get("unit","")
                    results["lst_stats"] = {
                        "min":  float(np.nanmin(valid)),
                        "max":  float(np.nanmax(valid)),
                        "mean": float(np.nanmean(valid)),
                        "std":  float(np.nanstd(valid)),
                        "unit": u,
                        "masked_pct": mask_statistics(qa_mask_arr)["pct_masked"],
                    }

            self.progress.emit(70, "Writing output GeoTIFFs…")
            out = p["output_dir"]
            ref = p["layer_therm"]
            suf = "C" if p["unit"] == "celsius" else "K"
            written = {}

            written["lst"] = write_output_raster(
                results["lst"], ref, os.path.join(out, f"LST_{suf}.tif"))
            if p.get("save_bt"):
                written["bt"] = write_output_raster(
                    results["bt_celsius"], ref, os.path.join(out, "BT_Celsius.tif"))
            if p.get("save_ndvi"):
                written["ndvi"] = write_output_raster(
                    results["ndvi"], ref, os.path.join(out, "NDVI.tif"))
            if p.get("save_emiss"):
                written["emissivity"] = write_output_raster(
                    results["emissivity"], ref, os.path.join(out, "Emissivity.tif"))

            written["_stats"] = results["lst_stats"]   # not a layer – popped in _done()
            self.progress.emit(100, "Done ✔")
            self.finished.emit(written)

        except Exception as e:
            self.error.emit(f"{type(e).__name__}: {e}\n\n{traceback.format_exc()}")


# ─────────────────────────────────────────────────────────────────────────────
# Logo pixmap (drawn with QPainter, no external file)
# ─────────────────────────────────────────────────────────────────────────────
def _make_logo(w: int = 660, h: int = 72) -> QPixmap:
    px = QPixmap(w, h)
    px.fill(Qt.transparent)
    p = QPainter(px)
    p.setRenderHint(QPainter.Antialiasing)

    # Background gradient
    g = QLinearGradient(0, 0, w, 0)
    g.setColorAt(0.00, QColor("#06213e"))
    g.setColorAt(0.45, QColor("#0a4a5a"))
    g.setColorAt(1.00, QColor("#0d8c6a"))
    p.fillRect(0, 0, w, h, g)

    # Orbit arc
    p.setPen(QPen(QColor(255, 255, 255, 28), 1.4))
    p.setBrush(Qt.NoBrush)
    p.drawArc(8, 4, 66, 66, 20 * 16, 140 * 16)

    cx, cy = 44, h // 2
    # Thermal glow rings
    for r, a in [(28, 28), (20, 50), (13, 72)]:
        c = QColor("#ff6d35"); c.setAlpha(a)
        p.setBrush(QBrush(c)); p.setPen(Qt.NoPen)
        p.drawEllipse(cx - r, cy - r, r * 2, r * 2)

    # Satellite body
    p.setPen(QPen(QColor("#5ce1e6"), 1.5))
    p.setBrush(QBrush(QColor("#0d7377")))
    p.drawRect(cx - 10, cy - 7, 20, 14)
    # Solar panels
    p.setBrush(QBrush(QColor("#26c6a8")))
    p.drawRect(cx - 29, cy - 4, 16, 8)
    p.drawRect(cx + 13, cy - 4, 16, 8)
    p.setPen(QPen(QColor("#5ce1e6"), 1))
    for i in range(1, 3):
        p.drawLine(cx - 29 + i * 5, cy - 4, cx - 29 + i * 5, cy + 4)
        p.drawLine(cx + 13 + i * 5, cy - 4, cx + 13 + i * 5, cy + 4)

    # Title
    p.setPen(QColor("#ffffff"))
    p.setFont(QFont("Segoe UI", 16, QFont.Bold))
    p.drawText(QRect(88, 7, w - 106, 28), Qt.AlignLeft | Qt.AlignVCenter,
               "Landsat LST Calculator")
    # Subtitle
    p.setPen(QColor("#8ecfda"))
    p.setFont(QFont("Segoe UI", 8))
    p.drawText(QRect(89, 37, w - 106, 20), Qt.AlignLeft | Qt.AlignVCenter,
               "Land Surface Temperature  ·  Landsat 5 / 7 / 8 / 9  "
               "·  Planck Inversion + NDVI Emissivity  ·  MTL Auto-Calibration")
    # Version pill
    p.setPen(Qt.NoPen)
    p.setBrush(QBrush(QColor(255, 255, 255, 28)))
    p.drawRoundedRect(w - 58, h // 2 - 11, 50, 22, 11, 11)
    p.setPen(QColor("#ffffff"))
    p.setFont(QFont("Segoe UI", 8, QFont.Bold))
    p.drawText(QRect(w - 58, h // 2 - 11, 50, 22), Qt.AlignCenter, "v 5.0")
    p.end()
    return px


# ─────────────────────────────────────────────────────────────────────────────
# Drag-and-drop zone
# ─────────────────────────────────────────────────────────────────────────────
class DropZone(QLabel):
    pathDropped = pyqtSignal(str)

    _IDLE_SS = ("border:2px dashed #9ab4cc; border-radius:8px; background:#eef5ff;"
                "color:#4a6a8a; font-size:12px; padding:8px;")
    _OVER_SS = ("border:2px dashed #0d7377; border-radius:8px; background:#d8f0f2;"
                "color:#0a5060; font-size:12px; padding:8px;")

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAcceptDrops(True)
        self.setAlignment(Qt.AlignCenter)
        self.setMinimumHeight(52)
        self.setStyleSheet(self._IDLE_SS)
        self._set_idle()

    def _set_idle(self):
        self.setText("📂  Drag & Drop  —  scene folder  ·  ZIP  ·  RAR\n"
                     "or  click to browse for folder")

    def mousePressEvent(self, _):
        path = QFileDialog.getExistingDirectory(None, "Select Landsat Scene Folder")
        if path:
            self._emit(path)

    def dragEnterEvent(self, e):
        if e.mimeData().hasUrls():
            e.acceptProposedAction()
            self.setStyleSheet(self._OVER_SS)

    def dragLeaveEvent(self, _):
        self.setStyleSheet(self._IDLE_SS)

    def dropEvent(self, e):
        self.setStyleSheet(self._IDLE_SS)
        urls = e.mimeData().urls()
        if not urls:
            return
        raw = urls[0].toLocalFile()
        ext = os.path.splitext(raw)[1].lower()
        if os.path.isdir(raw):
            self._emit(raw)
        elif ext == ".zip":
            self._unpack(raw)
        elif ext in (".rar", ".tar", ".gz", ".bz2"):
            self._unpack(raw)
        else:
            self._emit(os.path.dirname(raw))

    def _unpack(self, archive):
        try:
            tmp = tempfile.mkdtemp(prefix="lst_")
            if archive.lower().endswith(".zip"):
                with zipfile.ZipFile(archive) as z:
                    z.extractall(tmp)
            else:
                try:
                    import patoolib
                    patoolib.extract_archive(archive, outdir=tmp)
                except ImportError:
                    shutil.unpack_archive(archive, tmp)
            self.setText(f"✔  Extracted: {os.path.basename(archive)}")
            self._emit(tmp)
        except Exception as ex:
            QMessageBox.warning(None, "Extraction error",
                f"Could not extract archive:\n{ex}\n\nFor RAR: pip install patool")

    def _emit(self, folder):
        self.setText(f"✔  {os.path.basename(folder) or folder}")
        self.pathDropped.emit(folder)


# ─────────────────────────────────────────────────────────────────────────────
# Main dialog
# ─────────────────────────────────────────────────────────────────────────────
class LSTDialog(QDialog):

    SENSORS = [
        ("L5", "Landsat 5  (TM)"),
        ("L7", "Landsat 7  (ETM+)"),
        ("L8", "Landsat 8  (OLI/TIRS)"),
        ("L9", "Landsat 9  (OLI-2/TIRS-2)"),
    ]

    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface   = iface
        self.worker  = None
        self._folder  = ""
        self._mtl     = ""
        self._qa_path = ""          # path to QA_PIXEL band if found
        self.setWindowTitle("Landsat LST Calculator")
        self.setMinimumWidth(680)
        self.setStyleSheet(self._css())
        self._build_ui()

    # ── build ─────────────────────────────────────────────────────────────────
    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # Logo
        self._logo = QLabel()
        self._logo.setFixedHeight(72)
        self._logo.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        self._redraw_logo()
        root.addWidget(self._logo)

        # Scrollable body
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        body = QWidget(); body.setObjectName("body")
        bl   = QVBoxLayout(body)
        bl.setContentsMargins(16, 12, 16, 14)
        bl.setSpacing(10)
        scroll.setWidget(body)
        root.addWidget(scroll)

        # ── 1. Scene input ─────────────────────────────────────────────────
        g1 = QGroupBox("1 ·  Scene Input")
        l1 = QVBoxLayout(g1)
        self.drop_zone = DropZone()
        self.drop_zone.pathDropped.connect(self._on_folder)
        l1.addWidget(self.drop_zone)

        row_path = QHBoxLayout()
        lbl_f = QLabel("Folder:"); lbl_f.setFixedWidth(48)
        self.le_scene = QLineEdit(); self.le_scene.setReadOnly(True)
        self.le_scene.setPlaceholderText("Scene folder path…")
        lbl_m = QLabel("MTL:"); lbl_m.setFixedWidth(30)
        self.le_mtl = QLineEdit(); self.le_mtl.setReadOnly(True)
        self.le_mtl.setPlaceholderText("_MTL.txt (auto)")
        self.le_mtl.setFixedWidth(210)
        btn_clr = QPushButton("✕"); btn_clr.setFixedWidth(26)
        btn_clr.setToolTip("Clear scene")
        btn_clr.clicked.connect(self._clear_scene)
        row_path.addWidget(lbl_f); row_path.addWidget(self.le_scene, 2)
        row_path.addWidget(lbl_m); row_path.addWidget(self.le_mtl, 1)
        row_path.addWidget(btn_clr)
        l1.addLayout(row_path)
        bl.addWidget(g1)

        # ── 2. Sensor ──────────────────────────────────────────────────────
        g2  = QGroupBox("2 ·  Sensor")
        sg  = QGridLayout(g2)
        self._sbg = QButtonGroup(self)
        self._srb = {}
        for col, (key, lbl) in enumerate(self.SENSORS):
            rb = QRadioButton(lbl)
            if key == "L8": rb.setChecked(True)
            self._sbg.addButton(rb); self._srb[key] = rb
            sg.addWidget(rb, 0, col)
        self._sbg.buttonClicked.connect(lambda _: self._sensor_changed())
        bl.addWidget(g2)

        # ── 3. Input bands ─────────────────────────────────────────────────
        g3 = QGroupBox("3 ·  Input Bands  (auto-filled on folder load)")
        bg = QGridLayout(g3); bg.setColumnStretch(1, 1)
        bg.setContentsMargins(8, 4, 8, 6); bg.setVerticalSpacing(6)
        for c, h in enumerate(["Role", "Raster Layer"]):
            lbl = QLabel(f"<b>{h}</b>"); lbl.setObjectName("ch")
            bg.addWidget(lbl, 0, c)

        self._brows = {}
        for ri, (rk, rl, icon) in enumerate([
            ("therm", "Thermal Infrared", "🌡"),
            ("red",   "Red",              "🔴"),
            ("nir",   "NIR",              "🌿"),
        ], 1):
            lbl   = QLabel(f"{icon}  {rl}"); lbl.setFixedWidth(148)
            combo = QComboBox()
            combo.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
            bg.addWidget(lbl, ri, 0); bg.addWidget(combo, ri, 1)
            # spin always band=1, hidden; kept so _run() params unchanged
            spin = QSpinBox(); spin.setValue(1); spin.hide()
            self._brows[rk] = (combo, spin)
        bl.addWidget(g3)

        # ── 4. Cloud / Water Masking ──────────────────────────────────────────
        g_mask = QGroupBox("4 ·  Cloud / Water Masking  (QA_PIXEL)")
        ml = QVBoxLayout(g_mask)

        self.cb_mask = QCheckBox("Apply QA_PIXEL mask  —  removes cloud, shadow and fill pixels")
        self.cb_mask.setChecked(True)
        self.cb_mask.stateChanged.connect(self._toggle_mask_options)
        ml.addWidget(self.cb_mask)

        qa_row = QHBoxLayout()
        lbl_qa = QLabel("QA_PIXEL file:"); lbl_qa.setFixedWidth(105)
        self.le_qa = QLineEdit(); self.le_qa.setReadOnly(True)
        self.le_qa.setPlaceholderText("Auto-detected on folder load, or browse manually…")
        self.btn_qa = QPushButton("📁  Browse")
        self.btn_qa.setObjectName("browse_btn")
        self.btn_qa.setMinimumHeight(30); self.btn_qa.setMinimumWidth(96)
        self.btn_qa.setCursor(Qt.PointingHandCursor)
        self.btn_qa.clicked.connect(self._browse_qa)
        qa_row.addWidget(lbl_qa); qa_row.addWidget(self.le_qa, 1); qa_row.addWidget(self.btn_qa)
        ml.addLayout(qa_row)

        self.mask_opts = QWidget()
        opts_row = QHBoxLayout(self.mask_opts)
        opts_row.setContentsMargins(0, 2, 0, 0)
        opts_row.addWidget(QLabel("Mask:"))
        self.cb_m_cloud   = QCheckBox("Cloud");         self.cb_m_cloud.setChecked(True)
        self.cb_m_shadow  = QCheckBox("Shadow");        self.cb_m_shadow.setChecked(True)
        self.cb_m_cirrus  = QCheckBox("Cirrus");        self.cb_m_cirrus.setChecked(True)
        self.cb_m_dilated = QCheckBox("Dilated cloud"); self.cb_m_dilated.setChecked(True)
        self.cb_m_water   = QCheckBox("Water");         self.cb_m_water.setChecked(False)
        self.cb_m_snow    = QCheckBox("Snow/Ice");      self.cb_m_snow.setChecked(False)
        for w in (self.cb_m_cloud, self.cb_m_shadow, self.cb_m_cirrus,
                  self.cb_m_dilated, self.cb_m_water, self.cb_m_snow):
            opts_row.addWidget(w)
        opts_row.addStretch()
        ml.addWidget(self.mask_opts)

        self.lbl_mask_info = QLabel("")
        self.lbl_mask_info.setObjectName("mask_info")
        self.lbl_mask_info.setVisible(False)
        ml.addWidget(self.lbl_mask_info)
        bl.addWidget(g_mask)

        # ── 5. Output ─────────────────────────────────────────────────────────
        g4 = QGroupBox("5 ·  Output")
        ol = QVBoxLayout(g4)

        u_row = QHBoxLayout()
        u_row.addWidget(QLabel("Unit:"))
        self.rb_c = QRadioButton("Celsius (°C)"); self.rb_k = QRadioButton("Kelvin (K)")
        self.rb_c.setChecked(True)
        u_row.addWidget(self.rb_c); u_row.addWidget(self.rb_k); u_row.addStretch()
        ol.addLayout(u_row)

        e_row = QHBoxLayout()
        e_row.addWidget(QLabel("Also save:"))
        self.cb_bt   = QCheckBox("Brightness Temp.")
        self.cb_ndvi = QCheckBox("NDVI")
        self.cb_em   = QCheckBox("Emissivity")
        for w in (self.cb_bt, self.cb_ndvi, self.cb_em): e_row.addWidget(w)
        e_row.addStretch(); ol.addLayout(e_row)

        d_row = QHBoxLayout()
        lbl_out = QLabel("Output folder:"); lbl_out.setFixedWidth(90)
        self.le_out = QLineEdit(); self.le_out.setPlaceholderText("Select output folder…")
        btn_out = QPushButton("📁  Browse")
        btn_out.setObjectName("browse_btn")
        btn_out.setMinimumHeight(30); btn_out.setMinimumWidth(96)
        btn_out.setCursor(Qt.PointingHandCursor)
        btn_out.clicked.connect(self._browse_out)
        d_row.addWidget(lbl_out); d_row.addWidget(self.le_out, 1); d_row.addWidget(btn_out)
        ol.addLayout(d_row)

        self.cb_proj = QCheckBox("Add output layers to QGIS project")
        self.cb_proj.setChecked(True); ol.addWidget(self.cb_proj)
        bl.addWidget(g4)

        # ── Statistics ─────────────────────────────────────────────────────
        self.stats_box = QGroupBox("✔  LST Statistics")
        self.stats_box.setVisible(False)
        st = QGridLayout(self.stats_box)
        self._stat_lbl = {}   # keys: "min", "max", "mean", "std"
        for col, key in enumerate(["Min", "Max", "Mean", "Std Dev"]):
            h = QLabel(f"<b>{key}</b>"); h.setAlignment(Qt.AlignCenter)
            v = QLabel("—");            v.setObjectName("stat_val")
            v.setAlignment(Qt.AlignCenter)
            st.addWidget(h, 0, col); st.addWidget(v, 1, col)
            self._stat_lbl[key.lower().replace(" ", "")] = v   # "min","max","mean","stddev"
        bl.addWidget(self.stats_box)

        # ── Progress + log ─────────────────────────────────────────────────
        self.pbar = QProgressBar(); self.pbar.setValue(0)
        bl.addWidget(self.pbar)

        self.log = QTextEdit(); self.log.setReadOnly(True)
        self.log.setFixedHeight(80); self.log.setObjectName("log")
        bl.addWidget(self.log)

        # ── Action buttons ─────────────────────────────────────────────────
        btn_row = QHBoxLayout()
        self.btn_run   = QPushButton("▶   Calculate LST")
        self.btn_run.setObjectName("run_btn"); self.btn_run.setMinimumHeight(38)
        self.btn_close = QPushButton("Close"); self.btn_close.setMinimumHeight(38)
        self.btn_run.clicked.connect(self._run)
        self.btn_close.clicked.connect(self.close)
        btn_row.addStretch(); btn_row.addWidget(self.btn_run); btn_row.addWidget(self.btn_close)
        bl.addLayout(btn_row)

        # Initial combo population + live update
        self._pop_combos()
        QgsProject.instance().layersAdded.connect(self._pop_combos)
        QgsProject.instance().layersRemoved.connect(self._pop_combos)

    # ── logo ──────────────────────────────────────────────────────────────────
    def _redraw_logo(self):
        self._logo.setPixmap(_make_logo(max(self.width(), 680), 72))

    def resizeEvent(self, e):
        super().resizeEvent(e); self._redraw_logo()

    # ── folder / sensor ───────────────────────────────────────────────────────
    def _on_folder(self, folder: str):
        self._folder = folder
        self.le_scene.setText(folder)
        if not self.le_out.text():
            self.le_out.setText(folder)

        # MTL
        self._mtl = find_mtl_in_folder(folder)
        self.le_mtl.setText(os.path.basename(self._mtl) if self._mtl else "Not found")
        if self._mtl:
            self._log(f"MTL: {os.path.basename(self._mtl)}")
        else:
            self._log("⚠  MTL not found — using sensor default constants")

        # Auto-detect sensor
        det = detect_sensor_recursive(folder)
        if det:
            self._srb[det].setChecked(True)
            self._log(f"Sensor detected: {SENSOR_CONSTANTS[det]['desc']}")

        self._auto_bands(folder, self._sensor())

    def _clear_scene(self):
        self._folder = ""; self._mtl = ""
        self.le_scene.clear(); self.le_mtl.clear()
        self.drop_zone._set_idle()

    def _sensor_changed(self):
        if self._folder:
            self._auto_bands(self._folder, self._sensor())

    def _sensor(self) -> str:
        for k, rb in self._srb.items():
            if rb.isChecked(): return k
        return "L8"

    # ── band auto-detection ───────────────────────────────────────────────────
    def _auto_bands(self, folder: str, sensor: str):
        c = SENSOR_CONSTANTS[sensor]
        self._log(f"Scanning for {c['desc']} bands…")
        found = {}
        for role, pats in [
            ("therm", c["therm_pattern"]),
            ("red",   c["red_pattern"]),
            ("nir",   c["nir_pattern"]),
        ]:
            path = find_band_recursive(folder, pats)
            if path:
                lyr = self._load_lyr(path)
                if lyr:
                    self._pop_combos()
                    self._set_combo(role, lyr)
                    found[role] = os.path.basename(path)

        # Auto-detect QA_PIXEL band
        qa_pats = c.get("qa_pattern", ["_QA_PIXEL.TIF", "_BQA.TIF"])
        qa_path = find_band_recursive(folder, qa_pats)
        if qa_path:
            self._qa_path = qa_path
            self.le_qa.setText(os.path.basename(qa_path))
            self.cb_mask.setChecked(True)
            found["qa"] = os.path.basename(qa_path)
        else:
            self._qa_path = ""
            self.le_qa.clear()
            self.cb_mask.setChecked(False)
            self._log("  ⚠ QA_PIXEL not found — masking disabled")

        for role, fn in found.items():
            self._log(f"  ✔ {role:6s} ← {fn}")
        missing = [r for r in ("therm", "red", "nir") if r not in found]
        if missing:
            self._log(f"  ⚠ Not found: {', '.join(missing)}")
            self._log(f"    Searched patterns: "
                      f"{c['therm_pattern'] + c['red_pattern'] + c['nir_pattern']}")

    def _load_lyr(self, path: str) -> QgsRasterLayer:
        for lyr in QgsProject.instance().mapLayers().values():
            if lyr.source() == path: return lyr
        lyr = QgsRasterLayer(path, os.path.basename(path))
        if lyr.isValid():
            QgsProject.instance().addMapLayer(lyr); return lyr
        self._log(f"  ✘ Cannot load: {path}"); return None

    def _set_combo(self, role: str, lyr: QgsRasterLayer):
        combo, _ = self._brows[role]
        for i in range(combo.count()):
            if combo.itemData(i) == lyr.id():
                combo.setCurrentIndex(i); return

    # ── layer combos ──────────────────────────────────────────────────────────
    def _pop_combos(self, *_):
        lyrs = [l for l in QgsProject.instance().mapLayers().values()
                if isinstance(l, QgsRasterLayer) and l.isValid()]
        for rk in ("therm", "red", "nir"):
            combo, _ = self._brows[rk]
            cur = combo.currentData()
            combo.clear(); combo.addItem("— select layer —", None)
            for l in lyrs: combo.addItem(l.name(), l.id())
            if cur:
                for i in range(combo.count()):
                    if combo.itemData(i) == cur:
                        combo.setCurrentIndex(i); break

    def _get_lyr(self, role: str) -> QgsRasterLayer:
        combo, _ = self._brows[role]
        lid = combo.currentData()
        return QgsProject.instance().mapLayer(lid) if lid else None

    # ── mask toggle ───────────────────────────────────────────────────────────
    def _toggle_mask_options(self, state):
        enabled = bool(state)
        self.mask_opts_widget.setEnabled(enabled)
        self.le_qa.setEnabled(enabled)
        self.btn_qa.setEnabled(enabled)

    def _browse_qa(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Select QA_PIXEL Band", self._folder,
            "GeoTIFF files (*.TIF *.tif *.tiff)")
        if path:
            self._qa_path = path
            self.le_qa.setText(os.path.basename(path))

    # ── output browse ─────────────────────────────────────────────────────────
    def _browse_out(self):
        d = QFileDialog.getExistingDirectory(self, "Select Output Folder")
        if d: self.le_out.setText(d)

    # ── logging ───────────────────────────────────────────────────────────────
    def _log(self, msg: str):
        self.log.append(msg)

    # ── run ───────────────────────────────────────────────────────────────────
    def _run(self):
        lt = self._get_lyr("therm")
        lr = self._get_lyr("red")
        ln = self._get_lyr("nir")

        if not all([lt, lr, ln]):
            QMessageBox.warning(self, "Missing bands",
                "All three band roles must be assigned.\n"
                "Drop the scene folder into the drop zone to auto-fill."); return

        out = self.le_out.text().strip()
        if not out or not os.path.isdir(out):
            QMessageBox.warning(self, "Missing output",
                "Please select a valid output folder."); return

        _, st = self._brows["therm"]
        _, sr = self._brows["red"]
        _, sn = self._brows["nir"]

        params = dict(
            sensor    = self._sensor(),
            mtl_path  = self._mtl,
            layer_therm = lt, layer_red = lr, layer_nir = ln,
            band_therm  = st.value(), band_red = sr.value(), band_nir = sn.value(),
            unit       = "celsius" if self.rb_c.isChecked() else "kelvin",
            output_dir = out,
            save_bt    = self.cb_bt.isChecked(),
            save_ndvi  = self.cb_ndvi.isChecked(),
            save_emiss = self.cb_em.isChecked(),
            # Masking
            apply_mask   = self.cb_mask.isChecked() and bool(self._qa_path),
            qa_path      = self._qa_path,
            mask_cloud   = self.cb_m_cloud.isChecked(),
            mask_shadow  = self.cb_m_shadow.isChecked(),
            mask_cirrus  = self.cb_m_cirrus.isChecked(),
            mask_dilated = self.cb_m_dilated.isChecked(),
            mask_water   = self.cb_m_water.isChecked(),
            mask_snow    = self.cb_m_snow.isChecked(),
        )

        self.btn_run.setEnabled(False)
        self.pbar.setValue(0)
        self.log.clear()
        self.stats_box.setVisible(False)
        desc = SENSOR_CONSTANTS[params["sensor"]]["desc"]
        mtl_note = "with MTL" if self._mtl else "default constants"
        self._log(f"Starting: {desc}  [{params['unit']}]  ({mtl_note})")

        self.worker = LSTWorker(params)
        self.worker.progress.connect(lambda v, m: (self.pbar.setValue(v), self._log(m)))
        self.worker.finished.connect(self._done)
        self.worker.error.connect(self._err)
        self.worker.start()

    # ── done ──────────────────────────────────────────────────────────────────
    def _done(self, written: dict):
        stats = written.pop("_stats", {})   # remove non-layer entry first

        if self.cb_proj.isChecked():
            for key, lyr in written.items():
                if isinstance(lyr, QgsRasterLayer):   # BUG-FIX: skip non-layer values
                    QgsProject.instance().addMapLayer(lyr)
                    self._log(f"  Added to project: {lyr.name()}")

        if stats:
            u = stats.get("unit", "")
            self._stat_lbl["min"].setText(f"{stats['min']:.2f} {u}")
            self._stat_lbl["max"].setText(f"{stats['max']:.2f} {u}")
            self._stat_lbl["mean"].setText(f"{stats['mean']:.2f} {u}")
            self._stat_lbl["stddev"].setText(f"{stats['std']:.2f} {u}")
            self.stats_box.setVisible(True)
            self._log(f"  LST range: {stats['min']:.1f} – {stats['max']:.1f} {u}  "
                      f"mean={stats['mean']:.1f}  σ={stats['std']:.1f}")
            if "masked_pct" in stats:
                pct = stats["masked_pct"]
                self.lbl_mask_info.setText(
                    f"🛡  Masked: {pct:.1f}% of pixels removed (cloud/shadow/fill)")
            else:
                self.lbl_mask_info.setText("")

        self.btn_run.setEnabled(True)

    # ── error ─────────────────────────────────────────────────────────────────
    def _err(self, msg: str):
        self._log(f"ERROR:\n{msg}")
        self.btn_run.setEnabled(True)
        QMessageBox.critical(self, "LST Calculation Error", msg[:700])

    # ── stylesheet ────────────────────────────────────────────────────────────
    def _css(self) -> str:
        return """
        QDialog { background:#f3f7fb; color:#1a2540;
                  font-family:'Segoe UI',Arial,sans-serif; font-size:12px; }
        QScrollArea, QWidget#body { background:#f3f7fb; }

        QGroupBox { background:#ffffff; border:1px solid #d5e2ef;
                    border-radius:8px; margin-top:10px;
                    padding:10px 10px 8px 10px; }
        QGroupBox::title { subcontrol-origin:margin; left:12px; padding:0 6px;
                           color:#0a4d5e; font-size:10px; font-weight:bold;
                           text-transform:uppercase; letter-spacing:0.5px; }

        QLabel { color:#253550; }
        QLabel#ch { color:#7a99b5; font-size:10px; }
        QLabel#stat_val { font-size:16px; font-weight:bold; color:#0d7377; padding:4px; }

        QComboBox, QLineEdit, QSpinBox {
            background:#f6f9fc; border:1px solid #bccfdf;
            border-radius:5px; padding:4px 7px; color:#1a2540; }
        QComboBox:hover, QLineEdit:hover, QSpinBox:hover { border-color:#0d7377; }
        QLineEdit:focus { border:2px solid #0d7377; }
        QComboBox::drop-down { border:none; width:20px; }

        QRadioButton, QCheckBox { color:#253550; spacing:5px; }
        QRadioButton::indicator { width:13px; height:13px;
            border:2px solid #a5b8cc; border-radius:7px; background:white; }
        QRadioButton::indicator:checked { background:#0d7377; border-color:#0d7377; }
        QCheckBox::indicator { width:13px; height:13px;
            border:2px solid #a5b8cc; border-radius:3px; background:white; }
        QCheckBox::indicator:checked { background:#0d7377; border-color:#0d7377; }

        QProgressBar { background:#dde8f4; border:none; border-radius:5px;
                       height:14px; text-align:center; font-size:10px; color:#1a2540; }
        QProgressBar::chunk {
            background:qlineargradient(x1:0,y1:0,x2:1,y2:0,
                stop:0 #096472, stop:1 #13a07e);
            border-radius:5px; }

        QTextEdit#log { background:#edf2f8; border:1px solid #cad4e4;
                        border-radius:5px; color:#145230;
                        font-family:'Cascadia Code','Consolas',monospace; font-size:10px; }

        QLabel#mask_info { color:var(--color-text-info,#185fa5); font-size:11px;
                            background:#e6f1fb; border-radius:4px; padding:3px 8px; }
        QPushButton { background:#eaf0f8; border:1px solid #bccfdf;
                      border-radius:6px; padding:5px 14px; color:#253550;
                      min-height:28px; }
        QPushButton:hover { background:#dce8f6; border-color:#0d7377; color:#085f6d; }
        QPushButton#browse_btn {
            background:#ffffff; border:2px solid #0d7377;
            border-radius:6px; color:#0d7377; font-weight:bold;
            padding:4px 12px; min-width:96px; }
        QPushButton#browse_btn:hover {
            background:#e0f4f5; border-color:#085f6d; color:#085f6d; }

        QPushButton#run_btn {
            background:qlineargradient(x1:0,y1:0,x2:1,y2:0,
                stop:0 #085f6d, stop:1 #10937a);
            border:none; color:white; font-weight:bold;
            font-size:13px; min-width:168px; border-radius:6px; }
        QPushButton#run_btn:hover {
            background:qlineargradient(x1:0,y1:0,x2:1,y2:0,
                stop:0 #0a7a8a, stop:1 #16b890); }
        QPushButton#run_btn:disabled { background:#b2c2d0; color:#788898; }
        """
