# -*- coding: utf-8 -*-
"""Landsat LST Calculator - Main Plugin Class"""

import os
from qgis.PyQt.QtGui     import QIcon, QPixmap, QColor
from qgis.PyQt.QtWidgets import QAction


class LandsatLSTPlugin:

    def __init__(self, iface):
        self.iface      = iface
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.actions    = []
        self.menu       = "Landsat LST"
        self.toolbar    = self.iface.addToolBar("LandsatLST")
        self.toolbar.setObjectName("LandsatLST")
        self.dlg        = None

    def _icon(self):
        path = os.path.join(self.plugin_dir, "icon.png")
        if os.path.isfile(path):
            icon = QIcon(path)
            if not icon.pixmap(32, 32).isNull():
                return icon
        pm = QPixmap(32, 32)
        pm.fill(QColor(13, 115, 119))
        return QIcon(pm)

    def initGui(self):
        action = QAction(self._icon(), "Landsat LST Calculator",
                         self.iface.mainWindow())
        action.setToolTip(
            "Landsat LST Calculator\n"
            "Land Surface Temperature from Landsat 5 / 7 / 8 / 9"
        )
        action.triggered.connect(self.run)
        self.toolbar.addAction(action)
        self.iface.addPluginToRasterMenu(self.menu, action)
        self.actions.append(action)

    def unload(self):
        for action in self.actions:
            self.iface.removePluginRasterMenu(self.menu, action)
            self.iface.removeToolBarIcon(action)
        del self.toolbar

    def run(self):
        from .ui.lst_dialog import LSTDialog
        if self.dlg is None:
            self.dlg = LSTDialog(self.iface)
        self.dlg.show()
        self.dlg.raise_()
        self.dlg.activateWindow()
