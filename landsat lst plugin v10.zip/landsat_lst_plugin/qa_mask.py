# -*- coding: utf-8 -*-
"""
QA_PIXEL Cloud / Water / Shadow Masking
Collection-2 Landsat QA_PIXEL Band Bit Definitions (USGS LSDS-1619 Table 5)

Bit  Name
 0   Fill
 1   Dilated Cloud
 2   Cirrus (L8/L9 only)
 3   Cloud
 4   Cloud Shadow
 5   Snow
 6   Clear
 7   Water
 8   Cloud Confidence low    (2-bit: bits 8-9)
 9   Cloud Confidence high
10   Cloud Shadow Conf low   (2-bit: bits 10-11)
11   Cloud Shadow Conf high
12   Snow/Ice Conf low       (2-bit: bits 12-13)
13   Snow/Ice Conf high
14   Cirrus Conf low         (2-bit: bits 14-15)
15   Cirrus Conf high

For Collection-1 the QA band uses slightly different bit positions;
we handle both via a 'collection' parameter.
"""

import numpy as np


# ── Bit positions ─────────────────────────────────────────────────────────────
# Collection-2 (Landsat 8/9 OLI/TIRS, 7 ETM+, 5 TM)
BIT_FILL          = 0
BIT_DILATED_CLOUD = 1
BIT_CIRRUS        = 2
BIT_CLOUD         = 3
BIT_CLOUD_SHADOW  = 4
BIT_SNOW          = 5
BIT_CLEAR         = 6
BIT_WATER         = 7


def _bit(arr: np.ndarray, bit: int) -> np.ndarray:
    """Return boolean array where *bit* is set in *arr*."""
    return (arr.astype(np.uint16) >> bit & 1).astype(bool)


def build_mask(
    qa_arr:       np.ndarray,
    mask_cloud:   bool = True,
    mask_shadow:  bool = True,
    mask_water:   bool = False,
    mask_snow:    bool = False,
    mask_cirrus:  bool = True,
    mask_dilated: bool = True,
    mask_fill:    bool = True,
) -> np.ndarray:
    """
    Build a boolean mask from a QA_PIXEL array.

    Returns a 2-D boolean array where True = pixel should be MASKED (set to NaN).

    Parameters
    ----------
    qa_arr        : QA_PIXEL band as uint16 (or float64 — we cast internally)
    mask_cloud    : mask Bit 3  – Cloud
    mask_shadow   : mask Bit 4  – Cloud Shadow
    mask_water    : mask Bit 7  – Water
    mask_snow     : mask Bit 5  – Snow / Ice
    mask_cirrus   : mask Bit 2  – Cirrus (L8/L9 only; harmless for L5/L7)
    mask_dilated  : mask Bit 1  – Dilated Cloud (buffer around cloud edge)
    mask_fill     : mask Bit 0  – Fill / NoData pixels

    Returns
    -------
    mask : ndarray of bool, True where pixel is contaminated / invalid
    """
    qa = qa_arr.astype(np.uint16)
    bad = np.zeros(qa.shape, dtype=bool)

    if mask_fill:     bad |= _bit(qa, BIT_FILL)
    if mask_dilated:  bad |= _bit(qa, BIT_DILATED_CLOUD)
    if mask_cirrus:   bad |= _bit(qa, BIT_CIRRUS)
    if mask_cloud:    bad |= _bit(qa, BIT_CLOUD)
    if mask_shadow:   bad |= _bit(qa, BIT_CLOUD_SHADOW)
    if mask_snow:     bad |= _bit(qa, BIT_SNOW)
    if mask_water:    bad |= _bit(qa, BIT_WATER)

    return bad


def apply_mask(data: np.ndarray, mask: np.ndarray) -> np.ndarray:
    """
    Set masked pixels to NaN in *data*.
    Works in-place on a copy (does not modify original array).
    """
    out = data.astype(np.float64).copy()
    out[mask] = np.nan
    return out


def mask_statistics(mask: np.ndarray) -> dict:
    """
    Return a dict describing how many pixels were masked.
    Useful for logging / UI feedback.
    """
    total   = mask.size
    masked  = int(np.sum(mask))
    valid   = total - masked
    pct     = 100.0 * masked / total if total > 0 else 0.0
    return {
        "total":   total,
        "masked":  masked,
        "valid":   valid,
        "pct_masked": round(pct, 2),
    }


# ── QA file-name patterns (Collection-2) ──────────────────────────────────────
QA_PATTERNS = {
    "L5": ["_QA_PIXEL.TIF"],
    "L7": ["_QA_PIXEL.TIF"],
    "L8": ["_QA_PIXEL.TIF"],
    "L9": ["_QA_PIXEL.TIF"],
}

# Collection-1 used a different name
QA_PATTERNS_C1 = {
    "L5": ["_BQA.TIF"],
    "L7": ["_BQA.TIF"],
    "L8": ["_BQA.TIF"],
    "L9": ["_BQA.TIF"],
}
